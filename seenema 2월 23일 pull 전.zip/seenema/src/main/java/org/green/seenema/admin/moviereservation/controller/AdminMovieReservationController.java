package org.green.seenema.admin.moviereservation.controller;

import java.util.List;

import org.green.seenema.mapper.AdminReservationViewMapper;
import org.green.seenema.vo.ReservationVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequestMapping("/admin")
@Controller
public class AdminMovieReservationController {
	
	@Autowired
	AdminReservationViewMapper arMapper;

	// 영화 예매페이지
	@GetMapping("/adminReservationView")
	public void adminReplyView() {
	}
	@GetMapping("/reservationAllView")
	public @ResponseBody List<ReservationVO> getNoticeList() {

		return arMapper.reservationAllView();
	}
	
	@GetMapping("/reservationMainView")
	public @ResponseBody List<ReservationVO> reservationMainView() {

		return arMapper.reservationMainView();
	}


}

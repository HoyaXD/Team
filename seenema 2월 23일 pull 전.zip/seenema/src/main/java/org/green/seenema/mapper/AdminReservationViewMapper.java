package org.green.seenema.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.green.seenema.vo.ReservationVO;

@Mapper
public interface AdminReservationViewMapper {
	
	public List<ReservationVO> reservationAllView();
	
	public List<ReservationVO> reservationMainView();
	
	
}

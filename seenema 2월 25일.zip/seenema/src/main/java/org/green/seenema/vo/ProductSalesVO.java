package org.green.seenema.vo;

import lombok.Data;

@Data
public class ProductSalesVO {
	
	private String month;
	private String productName;
	private int take;
	private int totalPrice;
	private int total_count;
	private String gender;
	private int total_price;
	
}

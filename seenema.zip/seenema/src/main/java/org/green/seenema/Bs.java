package org.green.seenema;

public class Bs {
	String bs;
}

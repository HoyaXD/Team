package org.green.seenema.controller;

import java.util.ArrayList;

import org.green.seenema.mapper.SalesMapper;
import org.green.seenema.vo.MovieVO;
import org.green.seenema.vo.ProductVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
public class AdminMainController {
	
	@Autowired
	SalesMapper sMapper;
	
	  
   @GetMapping("/main")
   public String adminMain(Model model) {
	  //영화, 상품 판매율 top5 조회
	   ArrayList<MovieVO> mList = sMapper.getMovieTopfive();
	   ArrayList<ProductVO> pList = sMapper.getProductTopfive();
	   
	   model.addAttribute("mList", mList);
	   model.addAttribute("pList", pList);
	   
	   return "admin/adminMain";
   }
   
}
